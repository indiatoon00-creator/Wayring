#!/usr/bin/env python3
"""Regenerates the ring texture, block model and the village plaza NBT (no external libs needed).
Run from the project root:  python3 tools/make_assets.py"""
import gzip, json, os, random, struct, zlib

RES = "src/main/resources"
ASSETS = f"{RES}/assets/wayrings"
DATA = f"{RES}/data/wayrings"

# ------------------------------------------------------------------ texture (16x16 PNG)
random.seed(7)
px = []
for y in range(16):
    row = []
    for x in range(16):
        base = 128 + random.randint(-10, 10)
        mortar = (y % 8 == 0) or ((x + (4 if (y // 8) % 2 else 0)) % 8 == 0)
        r, g, b = (base - 45,) * 3 if mortar else (base, base, base + 6)
        row.append([r, g, b, 255])
    px.append(row)
for (x, y) in [(8, 2), (7, 3), (9, 3), (8, 4), (8, 10), (7, 11), (9, 11), (8, 12), (3, 6), (12, 6)]:
    px[y][x] = [90, 220, 255, 255]  # glowing rune pixels

def chunk(t, d):
    return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

raw = b"".join(b"\x00" + bytes(v for p in row for v in p) for row in px)
png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 16, 16, 8, 6, 0, 0, 0))
       + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))
with open(f"{ASSETS}/textures/block/wayring.png", "wb") as f:
    f.write(png)

# ------------------------------------------------------------------ block model (octagonal ring)
def el(frm, to, rot=None):
    e = {"from": frm, "to": to,
         "faces": {d: {"texture": "#0"} for d in ["north", "south", "east", "west", "up", "down"]}}
    if rot:
        e["rotation"] = rot
    return e

elements = [
    el([4, 14, 6], [12, 16, 10]), el([4, 0, 6], [12, 2, 10]),
    el([0, 4, 6], [2, 12, 10]), el([14, 4, 6], [16, 12, 10]),
    el([0.38, 12.5, 6], [4.62, 14.5, 10], {"origin": [2.5, 13.5, 8], "axis": "z", "angle": 45}),
    el([11.38, 12.5, 6], [15.62, 14.5, 10], {"origin": [13.5, 13.5, 8], "axis": "z", "angle": -45}),
    el([0.38, 1.5, 6], [4.62, 3.5, 10], {"origin": [2.5, 2.5, 8], "axis": "z", "angle": -45}),
    el([11.38, 1.5, 6], [15.62, 3.5, 10], {"origin": [13.5, 2.5, 8], "axis": "z", "angle": 45}),
]
json.dump({"parent": "minecraft:block/block",
           "textures": {"0": "wayrings:block/wayring", "particle": "wayrings:block/wayring"},
           "elements": elements}, open(f"{ASSETS}/models/block/wayring.json", "w"), indent=2)
json.dump({"parent": "wayrings:block/wayring"}, open(f"{ASSETS}/models/item/wayring.json", "w"), indent=2)
json.dump({"variants": {
    "facing=north": {"model": "wayrings:block/wayring"},
    "facing=east": {"model": "wayrings:block/wayring", "y": 90},
    "facing=south": {"model": "wayrings:block/wayring", "y": 180},
    "facing=west": {"model": "wayrings:block/wayring", "y": 270}}},
    open(f"{ASSETS}/blockstates/wayring.json", "w"), indent=2)

# ------------------------------------------------------------------ minimal NBT writer
def s(v):
    b = v.encode(); return struct.pack(">H", len(b)) + b
def t_int(v): return (3, struct.pack(">i", v))
def t_str(v): return (8, s(v))
def t_list(tid, payloads): return (9, bytes([tid]) + struct.pack(">i", len(payloads)) + b"".join(payloads))
def t_comp(entries):  # dict name -> (tid, payload)
    out = b"".join(bytes([tid]) + s(n) + p for n, (tid, p) in entries.items())
    return (10, out + b"\x00")
def int_list(vals): return t_list(3, [struct.pack(">i", v) for v in vals])

# ------------------------------------------------------------------ village plaza: 7 x 5 x 7
palette = [
    ("minecraft:air", None),                                                        # 0
    ("minecraft:stone_bricks", None),                                               # 1
    ("minecraft:polished_andesite", None),                                          # 2
    ("wayrings:wayring", {"facing": "south"}),                                      # 3
    ("minecraft:jigsaw", {"orientation": "south_up"}),                              # 4
    ("minecraft:stone_brick_wall", {"east": "none", "north": "none", "south": "none",
                                    "up": "true", "waterlogged": "false", "west": "none"}),  # 5
    ("minecraft:lantern", {"hanging": "false", "waterlogged": "false"}),            # 6
    ("minecraft:chiseled_stone_bricks", None),                                      # 7
]
SX, SY, SZ = 7, 5, 7
grid = {}
for x in range(SX):
    for z in range(SZ):
        inner = 2 <= x <= 4 and 2 <= z <= 4
        grid[(x, 0, z)] = 2 if inner else 1
        for y in range(1, SY):
            grid[(x, y, z)] = 0
grid[(3, 0, 3)] = 7
grid[(3, 1, 3)] = 3                       # the ring, facing south toward the street
grid[(3, 0, 6)] = 4                       # jigsaw on the south edge (connects to village streets)
for (cx, cz) in [(0, 0), (6, 0), (0, 6), (6, 6)]:
    grid[(cx, 1, cz)] = 5                 # corner posts
    grid[(cx, 2, cz)] = 6                 # lanterns

blocks = []
for (x, y, z), st in grid.items():
    e = {"pos": int_list([x, y, z]), "state": t_int(st)}
    if st == 3:
        e["nbt"] = t_comp({"id": t_str("wayrings:wayring")})
    if st == 4:
        e["nbt"] = t_comp({
            "id": t_str("minecraft:jigsaw"),
            "name": t_str("minecraft:building_entrance"),
            "target": t_str("minecraft:building_entrance"),
            "pool": t_str("minecraft:empty"),
            "joint": t_str("rollable"),
            "final_state": t_str("minecraft:stone_bricks")})
    blocks.append(t_comp(e)[1])

pal = []
for name, props in palette:
    e = {"Name": t_str(name)}
    if props:
        e["Properties"] = t_comp({k: t_str(v) for k, v in props.items()})
    pal.append(t_comp(e)[1])

root = t_comp({
    "size": int_list([SX, SY, SZ]),
    "entities": t_list(0, []),
    "blocks": t_list(10, blocks),
    "palette": t_list(10, pal),
    "DataVersion": t_int(3465),       # Minecraft 1.20.1
})
with gzip.open(f"{DATA}/structures/village/wayring_plaza.nbt", "wb") as f:
    f.write(bytes([10]) + s("") + root[1])
print("assets generated")
