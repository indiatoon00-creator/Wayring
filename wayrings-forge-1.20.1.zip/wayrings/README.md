# Wayring Teleporters (Forge 1.20.1)

Ancient teleport rings that spawn in villages and link them into a travel network.

## Build
1. Install **JDK 17**.
2. Download the **Forge 1.20.1 MDK (47.3.0)** from https://files.minecraftforge.net and copy its
   `gradlew`, `gradlew.bat` and `gradle/` folder into this project (the Gradle wrapper can't be bundled here).
3. `./gradlew build`  ->  jar in `build/libs/wayrings-1.0.0.jar`  (the one WITHOUT `-sources`)
4. Test: `./gradlew runClient`

## Rename the package
`com.example.wayrings` is a placeholder. Rename it to your own domain (IDE refactor) and update
`mod_group_id` + `mod_authors` in `gradle.properties`. Keep `mod_id=wayrings` unless you want to rename assets too.

## Quick in-game tests
- `/give @s wayrings:wayring` (place two, right-click one, pick the other)
- `/place template wayrings:village/wayring_plaza ~ ~ ~` places the village plaza by hand
- `/locate structure minecraft:village_plains` then fly there and look for the plaza
- Config: `config/wayrings-common.toml` (cost item, cooldown, spawn weight, pools)

## Regenerating assets
`python3 tools/make_assets.py` rebuilds the texture, block model and plaza NBT.
