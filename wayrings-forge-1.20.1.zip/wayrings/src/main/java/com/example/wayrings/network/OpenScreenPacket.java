package com.example.wayrings.network;

import com.example.wayrings.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.function.Supplier;

/** Server -> client: "open the destination list for the ring at origin". */
public record OpenScreenPacket(BlockPos origin, String costItem, int costCount, List<Dest> dests) {

    public record Dest(String name, String dim, BlockPos pos) {}

    public static void encode(OpenScreenPacket p, FriendlyByteBuf buf) {
        buf.writeBlockPos(p.origin);
        buf.writeUtf(p.costItem);
        buf.writeVarInt(p.costCount);
        buf.writeVarInt(p.dests.size());
        for (Dest d : p.dests) {
            buf.writeUtf(d.name());
            buf.writeUtf(d.dim());
            buf.writeBlockPos(d.pos());
        }
    }

    public static OpenScreenPacket decode(FriendlyByteBuf buf) {
        BlockPos origin = buf.readBlockPos();
        String costItem = buf.readUtf();
        int costCount = buf.readVarInt();
        int n = buf.readVarInt();
        List<Dest> list = new java.util.ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(new Dest(buf.readUtf(), buf.readUtf(), buf.readBlockPos()));
        }
        return new OpenScreenPacket(origin, costItem, costCount, list);
    }

    public static void handle(OpenScreenPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openScreen(p)));
        ctx.get().setPacketHandled(true);
    }
}
