package com.example.wayrings.client;

import com.example.wayrings.network.OpenScreenPacket;
import net.minecraft.client.Minecraft;

/** Isolated so server-only JVMs never load client classes. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openScreen(OpenScreenPacket packet) {
        Minecraft.getInstance().setScreen(new WayringScreen(packet));
    }
}
