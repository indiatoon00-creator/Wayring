package com.example.wayrings;

import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.structure.pools.StructurePoolElement;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;
import net.minecraftforge.event.server.ServerAboutToStartEvent;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * Adds the Wayring plaza jigsaw piece to village "houses" pools at server start.
 * Fields are found by TYPE (not name) so this works with both dev (official) and
 * production (SRG) names without an access transformer.
 */
public final class VillageInjector {
    private static final String PIECE = Wayrings.MODID + ":village/wayring_plaza";

    private VillageInjector() {}

    public static void onServerAboutToStart(ServerAboutToStartEvent event) {
        int weight = WayringConfig.PLAZA_WEIGHT.get();
        if (weight <= 0) return;

        Registry<StructureTemplatePool> pools =
                event.getServer().registryAccess().registryOrThrow(Registries.TEMPLATE_POOL);

        for (String id : WayringConfig.VILLAGE_POOLS.get()) {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl == null) continue;
            pools.getOptional(rl).ifPresentOrElse(
                    pool -> inject(pool, weight, id),
                    () -> Wayrings.LOGGER.debug("Wayrings: pool {} not present, skipped", id));
        }
    }

    @SuppressWarnings("unchecked")
    private static void inject(StructureTemplatePool pool, int weight, String id) {
        try {
            Field rawField = null;
            Field templatesField = null;
            for (Field f : StructureTemplatePool.class.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                if (f.getType() == ObjectArrayList.class) templatesField = f;
                else if (f.getType() == List.class) rawField = f;
            }
            if (rawField == null || templatesField == null) {
                Wayrings.LOGGER.warn("Wayrings: could not locate template pool fields; skipping {}", id);
                return;
            }
            rawField.setAccessible(true);
            templatesField.setAccessible(true);

            List<Pair<StructurePoolElement, Integer>> raw =
                    new ArrayList<>((List<Pair<StructurePoolElement, Integer>>) rawField.get(pool));
            for (Pair<StructurePoolElement, Integer> p : raw) {
                if (p.getFirst().toString().contains("wayring_plaza")) return; // already injected
            }

            StructurePoolElement element = StructurePoolElement.single(PIECE)
                    .apply(StructureTemplatePool.Projection.RIGID);

            raw.add(Pair.of(element, weight));
            rawField.set(pool, raw); // original list may be immutable, so replace it

            ObjectArrayList<StructurePoolElement> templates =
                    (ObjectArrayList<StructurePoolElement>) templatesField.get(pool);
            for (int i = 0; i < weight; i++) templates.add(element);

            Wayrings.LOGGER.debug("Wayrings: injected plaza into {} (weight {})", id, weight);
        } catch (Exception e) {
            Wayrings.LOGGER.error("Wayrings: failed to inject into pool " + id, e);
        }
    }
}
