package com.example.wayrings;

import com.mojang.logging.LogUtils;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import com.example.wayrings.network.WayringNetwork;
import org.slf4j.Logger;

@Mod(Wayrings.MODID)
public class Wayrings {
    public static final String MODID = "wayrings";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Wayrings() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModRegistry.register(modBus);
        modBus.addListener(this::commonSetup);
        modBus.addListener(this::buildCreativeTabs);

        // Village pool injection happens when a world/server starts
        MinecraftForge.EVENT_BUS.addListener(VillageInjector::onServerAboutToStart);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, WayringConfig.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(WayringNetwork::register);
    }

    private void buildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModRegistry.WAYRING_ITEM);
        }
    }
}
