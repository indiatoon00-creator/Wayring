package com.example.wayrings.logic;

import com.example.wayrings.ModRegistry;
import com.example.wayrings.WayringConfig;
import com.example.wayrings.block.WayringBlock;
import com.example.wayrings.data.WayringData;
import com.example.wayrings.network.OpenScreenPacket;
import com.example.wayrings.network.WayringNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;

/** All server-side rules: listing destinations, validating, charging the cost, teleporting. */
public final class WayringService {
    private static final Map<UUID, Long> COOLDOWN_UNTIL = new HashMap<>();
    private static final int MAX_LIST = 100;

    private WayringService() {}

    public static Item costItem() {
        Item item = ForgeRegistries.ITEMS.getValue(ResourceLocation.tryParse(WayringConfig.COST_ITEM.get()));
        return (item == null || item == Items.AIR) ? Items.EMERALD : item;
    }

    /** Called from the block's use(): send the player a list of destinations, nearest first. */
    public static void openMenu(ServerPlayer player, ServerLevel level, BlockPos origin) {
        WayringData data = WayringData.get(level.getServer());
        data.register(level.dimension(), origin); // self-heal if it was somehow missing

        boolean cross = WayringConfig.CROSS_DIMENSION.get();
        List<WayringData.Ring> rings = new ArrayList<>();
        for (WayringData.Ring r : data.all()) {
            boolean same = r.dim().equals(level.dimension());
            if (same && r.pos().equals(origin)) continue;
            if (!same && !cross) continue;
            rings.add(r);
        }
        rings.sort(Comparator.comparingDouble((WayringData.Ring r) ->
                r.dim().equals(level.dimension()) ? r.pos().distSqr(origin) : 1.0E18));

        List<OpenScreenPacket.Dest> dests = new ArrayList<>();
        for (WayringData.Ring r : rings) {
            if (dests.size() >= MAX_LIST) break;
            dests.add(new OpenScreenPacket.Dest(r.name(), r.dim().location().toString(), r.pos()));
        }

        ResourceLocation costId = ForgeRegistries.ITEMS.getKey(costItem());
        WayringNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new OpenScreenPacket(origin, String.valueOf(costId), WayringConfig.COST_COUNT.get(), dests));
    }

    /** Called from TeleportRequestPacket. Never trust the client: validate everything here. */
    public static void teleport(ServerPlayer player, BlockPos origin, String destDim, BlockPos destPos) {
        MinecraftServer server = player.server;
        ServerLevel from = player.serverLevel();

        // 1) Player must really be standing at a ring
        if (player.distanceToSqr(Vec3.atCenterOf(origin)) > 64.0
                || !from.getBlockState(origin).is(ModRegistry.WAYRING.get())) {
            return;
        }

        // 2) Cooldown (prevents spam and ping-pong loops)
        long now = server.overworld().getGameTime();
        Long until = COOLDOWN_UNTIL.get(player.getUUID());
        if (until != null && now < until) {
            long secs = (until - now + 19) / 20;
            player.displayClientMessage(Component.translatable("message.wayrings.cooldown", secs), true);
            return;
        }

        // 3) Destination must be a registered ring
        ResourceLocation destRl = ResourceLocation.tryParse(destDim);
        if (destRl == null) return;
        ResourceKey<Level> destKey = ResourceKey.create(Registries.DIMENSION, destRl);
        WayringData data = WayringData.get(server);
        if (data.get(destKey, destPos) == null) {
            player.displayClientMessage(Component.translatable("message.wayrings.unknown"), true);
            return;
        }
        ServerLevel to = server.getLevel(destKey);
        if (to == null || (to != from && !WayringConfig.CROSS_DIMENSION.get())) {
            player.displayClientMessage(Component.translatable("message.wayrings.unknown"), true);
            return;
        }

        // 4) Load the destination chunk and verify the ring still exists
        to.getChunkAt(destPos);
        BlockState destState = to.getBlockState(destPos);
        if (!destState.is(ModRegistry.WAYRING.get())) {
            data.unregister(destKey, destPos);
            player.displayClientMessage(Component.translatable("message.wayrings.vanished"), true);
            return;
        }

        Vec3 landing = findLanding(to, destPos, destState.getValue(WayringBlock.FACING));
        if (landing == null) {
            player.displayClientMessage(Component.translatable("message.wayrings.blocked"), true);
            return;
        }

        // 5) Pay
        if (!payCost(player)) return;

        // 6) Go
        Direction facing = destState.getValue(WayringBlock.FACING);
        effects(from, player.position(), false);
        player.teleportTo(to, landing.x, landing.y, landing.z, facing.toYRot(), 0.0F);
        player.resetFallDistance();
        effects(to, landing, true);

        COOLDOWN_UNTIL.put(player.getUUID(), now + WayringConfig.COOLDOWN_SECONDS.get() * 20L);
    }

    private static boolean payCost(ServerPlayer player) {
        int cost = WayringConfig.COST_COUNT.get();
        if (cost <= 0 || player.getAbilities().instabuild) return true;
        Item item = costItem();
        Predicate<ItemStack> match = st -> st.is(item);
        int have = player.getInventory().clearOrCountMatchingItems(match, 0, player.inventoryMenu.getCraftSlots());
        if (have < cost) {
            player.displayClientMessage(
                    Component.translatable("message.wayrings.need", cost, item.getDescription()), true);
            return false;
        }
        player.getInventory().clearOrCountMatchingItems(match, cost, player.inventoryMenu.getCraftSlots());
        player.inventoryMenu.broadcastChanges();
        return true;
    }

    /** Stand in front of the ring (or behind it as a fallback), on solid ground, with 2 blocks of headroom. */
    private static Vec3 findLanding(ServerLevel level, BlockPos ring, Direction facing) {
        for (Direction d : new Direction[]{facing, facing.getOpposite()}) {
            BlockPos base = ring.relative(d);
            for (int dy = 0; dy >= -2; dy--) {
                BlockPos q = base.offset(0, dy, 0);
                if (isFree(level, q) && isFree(level, q.above()) && !isFree(level, q.below())) {
                    return new Vec3(q.getX() + 0.5, q.getY(), q.getZ() + 0.5);
                }
            }
        }
        return null;
    }

    private static boolean isFree(ServerLevel level, BlockPos p) {
        return level.getBlockState(p).getCollisionShape(level, p).isEmpty();
    }

    private static void effects(ServerLevel level, Vec3 at, boolean arrival) {
        level.sendParticles(ParticleTypes.PORTAL, at.x, at.y + 1.0, at.z, 60, 0.4, 0.8, 0.4, 0.3);
        level.sendParticles(ParticleTypes.ENCHANT, at.x, at.y + 1.5, at.z, 30, 0.5, 0.5, 0.5, 0.5);
        level.playSound(null, BlockPos.containing(at), SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.PLAYERS, 0.8F, arrival ? 1.2F : 0.8F);
    }
}
