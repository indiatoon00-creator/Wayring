package com.example.wayrings.data;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/** World-saved registry of every ring (all dimensions). Stored once, in the overworld's data folder. */
public class WayringData extends SavedData {
    public record Ring(ResourceKey<Level> dim, BlockPos pos, String name) {}

    private static final String NAME = "wayrings_network";
    private final Map<String, Ring> rings = new LinkedHashMap<>();

    public static WayringData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(WayringData::load, WayringData::new, NAME);
    }

    private static String key(ResourceKey<Level> dim, BlockPos pos) {
        return dim.location() + "|" + pos.asLong();
    }

    public boolean register(ResourceKey<Level> dim, BlockPos pos) {
        String k = key(dim, pos);
        if (rings.containsKey(k)) return false;
        BlockPos p = pos.immutable();
        rings.put(k, new Ring(dim, p, WayringNames.generate(p)));
        setDirty();
        return true;
    }

    public void unregister(ResourceKey<Level> dim, BlockPos pos) {
        if (rings.remove(key(dim, pos)) != null) setDirty();
    }

    public Ring get(ResourceKey<Level> dim, BlockPos pos) {
        return rings.get(key(dim, pos));
    }

    public Collection<Ring> all() {
        return rings.values();
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Ring r : rings.values()) {
            CompoundTag t = new CompoundTag();
            t.putString("dim", r.dim().location().toString());
            t.putLong("pos", r.pos().asLong());
            t.putString("name", r.name());
            list.add(t);
        }
        tag.put("rings", list);
        return tag;
    }

    public static WayringData load(CompoundTag tag) {
        WayringData data = new WayringData();
        ListTag list = tag.getList("rings", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            ResourceLocation rl = ResourceLocation.tryParse(t.getString("dim"));
            if (rl == null) continue;
            ResourceKey<Level> dim = ResourceKey.create(Registries.DIMENSION, rl);
            BlockPos pos = BlockPos.of(t.getLong("pos"));
            data.rings.put(key(dim, pos), new Ring(dim, pos, t.getString("name")));
        }
        return data;
    }
}
