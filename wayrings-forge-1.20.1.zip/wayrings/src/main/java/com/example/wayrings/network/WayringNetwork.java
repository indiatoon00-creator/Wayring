package com.example.wayrings.network;

import com.example.wayrings.Wayrings;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class WayringNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Wayrings.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private WayringNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, OpenScreenPacket.class,
                OpenScreenPacket::encode, OpenScreenPacket::decode, OpenScreenPacket::handle);
        CHANNEL.registerMessage(id++, TeleportRequestPacket.class,
                TeleportRequestPacket::encode, TeleportRequestPacket::decode, TeleportRequestPacket::handle);
    }
}
