package com.example.wayrings;

import com.example.wayrings.block.WayringBlock;
import com.example.wayrings.block.WayringBlockEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, Wayrings.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Wayrings.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Wayrings.MODID);

    public static final RegistryObject<Block> WAYRING = BLOCKS.register("wayring",
            () -> new WayringBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(4.0F, 6.0F)
                    .sound(SoundType.STONE)
                    .lightLevel(state -> 7)
                    .noOcclusion()
                    .requiresCorrectToolForDrops()));

    public static final RegistryObject<Item> WAYRING_ITEM = ITEMS.register("wayring",
            () -> new BlockItem(WAYRING.get(), new Item.Properties()));

    public static final RegistryObject<BlockEntityType<WayringBlockEntity>> WAYRING_BE =
            BLOCK_ENTITIES.register("wayring",
                    () -> BlockEntityType.Builder.of(WayringBlockEntity::new, WAYRING.get()).build(null));

    private ModRegistry() {}

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
    }
}
