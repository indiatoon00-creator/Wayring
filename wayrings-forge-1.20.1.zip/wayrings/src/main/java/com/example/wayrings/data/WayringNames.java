package com.example.wayrings.data;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;

public final class WayringNames {
    private static final String[] ADJ = {"Amber", "Quiet", "Golden", "Mossy", "Windy", "Ember", "Silver",
            "Hollow", "Sunlit", "Old", "Bright", "Misty", "Stone", "Crimson", "Willow", "Azure"};
    private static final String[] NOUN = {"Crossing", "Hearth", "Gate", "Meadow", "Rest", "Haven", "Vale",
            "Ford", "Landing", "Bridge", "Hollow", "Green", "Watch", "Market", "Reach", "Well"};

    private WayringNames() {}

    /** Deterministic from position, so a name never changes. */
    public static String generate(BlockPos pos) {
        RandomSource rng = RandomSource.create(pos.asLong() * 31L + 7L);
        return ADJ[rng.nextInt(ADJ.length)] + " " + NOUN[rng.nextInt(NOUN.length)];
    }
}
