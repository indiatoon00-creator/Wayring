package com.example.wayrings;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class WayringConfig {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.ConfigValue<String> COST_ITEM = B
            .comment("Item consumed per teleport (registry id).")
            .define("costItem", "minecraft:emerald");

    public static final ForgeConfigSpec.IntValue COST_COUNT = B
            .comment("How many of the cost item are consumed per teleport. 0 = free.")
            .defineInRange("costCount", 1, 0, 64);

    public static final ForgeConfigSpec.IntValue COOLDOWN_SECONDS = B
            .comment("Per-player cooldown after a teleport.")
            .defineInRange("cooldownSeconds", 5, 0, 3600);

    public static final ForgeConfigSpec.BooleanValue CROSS_DIMENSION = B
            .comment("Allow travel between dimensions (e.g. Overworld <-> modded dimensions).")
            .define("crossDimension", true);

    public static final ForgeConfigSpec.IntValue PLAZA_WEIGHT = B
            .comment("Spawn weight of the Wayring plaza inside each village house pool. 0 disables village spawning.")
            .defineInRange("villagePlazaWeight", 4, 0, 100);

    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> VILLAGE_POOLS = B
            .comment("Template pools the plaza is injected into. Add pools from other village mods here.")
            .defineListAllowEmpty("villageHousePools", List.of(
                    "minecraft:village/plains/houses",
                    "minecraft:village/desert/houses",
                    "minecraft:village/savanna/houses",
                    "minecraft:village/snowy/houses",
                    "minecraft:village/taiga/houses"
            ), o -> o instanceof String);

    public static final ForgeConfigSpec SPEC = B.build();

    private WayringConfig() {}
}
