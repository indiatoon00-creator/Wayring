package com.example.wayrings.client;

import com.example.wayrings.network.OpenScreenPacket;
import com.example.wayrings.network.TeleportRequestPacket;
import com.example.wayrings.network.WayringNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;

/** Paged list of destination buttons. Pure Screen (no container menu needed). */
public class WayringScreen extends Screen {
    private static final int PER_PAGE = 5;
    private final OpenScreenPacket data;
    private int page = 0;

    public WayringScreen(OpenScreenPacket data) {
        super(Component.translatable("screen.wayrings.title"));
        this.data = data;
    }

    @Override
    protected void init() {
        int w = 220, h = 20, x = (width - w) / 2;
        int top = 50;
        int start = page * PER_PAGE;
        int end = Math.min(data.dests().size(), start + PER_PAGE);

        for (int i = start; i < end; i++) {
            OpenScreenPacket.Dest d = data.dests().get(i);
            addRenderableWidget(Button.builder(label(d), b -> select(d))
                    .bounds(x, top + (i - start) * 24, w, h)
                    .tooltip(Tooltip.create(Component.literal(
                            d.dim() + "  [" + d.pos().getX() + ", " + d.pos().getY() + ", " + d.pos().getZ() + "]")))
                    .build());
        }

        int navY = top + PER_PAGE * 24 + 4;
        Button prev = addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            page--;
            rebuildWidgets();
        }).bounds(x, navY, 20, 20).build());
        prev.active = page > 0;

        Button next = addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            page++;
            rebuildWidgets();
        }).bounds(x + w - 20, navY, 20, 20).build());
        next.active = end < data.dests().size();

        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(width / 2 - 40, navY, 80, 20).build());
    }

    private Component label(OpenScreenPacket.Dest d) {
        Minecraft mc = Minecraft.getInstance();
        String where;
        if (mc.level != null && mc.player != null && mc.level.dimension().location().toString().equals(d.dim())) {
            int dist = (int) Math.sqrt(mc.player.blockPosition().distSqr(d.pos()));
            where = dist + " m";
        } else {
            String path = d.dim().substring(d.dim().indexOf(':') + 1).replace('_', ' ');
            where = path.substring(0, 1).toUpperCase(Locale.ROOT) + path.substring(1);
        }
        return Component.literal(d.name() + "  (" + where + ")");
    }

    private void select(OpenScreenPacket.Dest d) {
        WayringNetwork.CHANNEL.sendToServer(new TeleportRequestPacket(data.origin(), d.dim(), d.pos()));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, 16, 0xFFFFFF);

        if (data.costCount() > 0) {
            Item item = ForgeRegistries.ITEMS.getValue(ResourceLocation.tryParse(data.costItem()));
            Component name = item != null ? item.getDescription() : Component.literal(data.costItem());
            g.drawCenteredString(font, Component.translatable("screen.wayrings.cost", data.costCount(), name),
                    width / 2, 30, 0xA0A0A0);
        }
        if (data.dests().isEmpty()) {
            g.drawCenteredString(font, Component.translatable("screen.wayrings.empty"),
                    width / 2, 80, 0xFF8080);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
