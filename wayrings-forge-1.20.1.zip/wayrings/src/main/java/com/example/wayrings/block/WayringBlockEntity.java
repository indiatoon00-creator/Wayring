package com.example.wayrings.block;

import com.example.wayrings.ModRegistry;
import com.example.wayrings.data.WayringData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Exists mainly so village-generated rings register themselves in the network
 * as soon as their chunk becomes a live LevelChunk (worldgen -> onLoad).
 */
public class WayringBlockEntity extends BlockEntity {
    public WayringBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistry.WAYRING_BE.get(), pos, state);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level instanceof ServerLevel sl) {
            WayringData.get(sl.getServer()).register(sl.dimension(), worldPosition);
        }
    }
}
