package com.example.wayrings.network;

import com.example.wayrings.logic.WayringService;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: "teleport me from this ring to that ring". Server re-validates everything. */
public record TeleportRequestPacket(BlockPos origin, String destDim, BlockPos destPos) {

    public static void encode(TeleportRequestPacket p, FriendlyByteBuf buf) {
        buf.writeBlockPos(p.origin);
        buf.writeUtf(p.destDim);
        buf.writeBlockPos(p.destPos);
    }

    public static TeleportRequestPacket decode(FriendlyByteBuf buf) {
        return new TeleportRequestPacket(buf.readBlockPos(), buf.readUtf(), buf.readBlockPos());
    }

    public static void handle(TeleportRequestPacket p, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (sender != null) WayringService.teleport(sender, p.origin, p.destDim, p.destPos);
        });
        ctx.get().setPacketHandled(true);
    }
}
