# CurseForge upload kit

## Project settings
- **Game / Type:** Minecraft Java Edition -> Mods
- **Name:** Wayring Teleporters   **Slug:** wayring-teleporters
- **Summary (<=250 chars):** Ancient teleport rings now stand in villages. Discover them, pay a small tribute, and travel between villages instantly.
- **Suggested categories (verify names in the CurseForge picker):** World Gen (Structures), Adventure and RPG, Utility & QoL
- **Game version:** 1.20.1   **Mod loader:** Forge   **Java:** 17
- **Environment:** Required on both client and server (the GUI is client-side, rules are server-side)
- **License:** pick one that matches `mod_license` (MIT is simple). Add a square logo (e.g. 400x400).
- **Release file:** `build/libs/wayrings-1.0.0.jar` (not the -sources jar). Release type: Beta first, then Release.

## Description (paste into the project page)

### Overview
Villages hide an old secret: **Wayrings**, ring-shaped stone gates that hum with enchantment energy.
Find one in a village, and it joins your travel network. Right-click any ring, pick another village,
pay a small tribute, and step out on the other side.

### Features
- New **Wayring** block with a custom octagonal ring model, glowing particles and light.
- **Spawns inside vanilla villages** (plains, desert, savanna, snowy, taiga) as a small stone plaza.
- Every ring **registers itself** on world load; destinations are stored per world and saved safely.
- Clean **destination menu** sorted by distance, with village names and cross-dimension support.
- **Balanced travel:** costs 1 Emerald by default, 5-second cooldown, portal particles and sounds.
- **Craftable:** 8 Stone Bricks + 1 Eye of Ender, so you can link your own base too.
- Fully **configurable**: cost item/amount, cooldown, spawn weight, which village pools to use.

### How to use
1. Find a village and look for the stone plaza with a ring.
2. Right-click the ring to open the menu. Rings appear in the list once their chunk has been loaded (explore to discover more).
3. Pick a destination. The cost is taken from your inventory (free in Creative).
4. Craft your own rings to build a personal network.

### Compatibility
- Minecraft 1.20.1, Forge 47.x. Works in singleplayer and on servers (install on both sides).
- Village mods: add their house pool IDs to `villageHousePools` in `config/wayrings-common.toml`.
- Safe to add to existing worlds: only newly generated village chunks get rings (or place/craft one).

### Known limitations
- Rings in never-generated villages cannot be listed yet.

## Tags (CurseForge "Tags"/keywords)
teleport, teleportation, villages, structures, travel, fast travel, waypoint, portal, worldgen, forge, 1.20.1
